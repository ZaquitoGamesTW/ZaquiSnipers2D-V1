import pygame
import sys
import math
import random

# Initialize Pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 600
FPS = 60
PLAYER_RADIUS = 15
ENEMY_SIZE = 20
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLACK = (0, 0, 0)
PLAYER_SPEED = 1
ENEMY_SPEED = 1

WEAPONS = {
    'revolver': {'key': pygame.K_r, 'damage': 50, 'cooldown': 500},
    'sniper': {'key': pygame.K_o, 'damage': 100, 'cooldown': 1000},
    'ak47': {'key': pygame.K_p, 'damage': 20, 'cooldown': 100}
}

fullscreen = True
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN if fullscreen else 0)
WIDTH, HEIGHT = screen.get_size()
pygame.display.set_caption("ZaquiSnipers2D - Update 1.00")
clock = pygame.time.Clock()

try:
    pygame.mixer.music.load("background_music.mp3")
    pygame.mixer.music.play(-1)
except:
    print("No se pudo cargar la música de fondo")

font = pygame.font.SysFont(None, 30)
large_font = pygame.font.SysFont(None, 80)

class Player:
    def __init__(self, x, y, is_main=False):
        self.x = x
        self.y = y
        self.color = GREEN
        self.radius = PLAYER_RADIUS
        self.last_shot = 0
        self.is_main = is_main
        self.health = 300
        self.alive = True

    def draw(self):
        if not self.alive:
            return
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), self.radius)
        health_bar_width = 40
        health_ratio = self.health / 300
        pygame.draw.rect(screen, RED, (self.x - health_bar_width // 2, self.y - self.radius - 10, health_bar_width, 5))
        pygame.draw.rect(screen, GREEN, (self.x - health_bar_width // 2, self.y - self.radius - 10, health_bar_width * health_ratio, 5))

        health_text = font.render(f"{int(self.health)}", True, WHITE)
        screen.blit(health_text, (self.x - health_text.get_width() // 2, self.y - self.radius - 30))

    def shoot(self, bullets, weapon, target_x, target_y):
        if not self.alive:
            return
        now = pygame.time.get_ticks()
        if now - self.last_shot > WEAPONS[weapon]['cooldown']:
            angle = math.atan2(target_y - self.y, target_x - self.x)
            bullets.append(Bullet(self.x, self.y, angle, WEAPONS[weapon]['damage']))
            self.last_shot = now

    def move(self, keys=None):
        if not self.alive:
            return
        if self.is_main and keys:
            if keys[pygame.K_w]: self.y -= PLAYER_SPEED
            if keys[pygame.K_s]: self.y += PLAYER_SPEED
            if keys[pygame.K_a]: self.x -= PLAYER_SPEED
            if keys[pygame.K_d]: self.x += PLAYER_SPEED
        else:
            if enemies:
                target = enemies[0]
                dx = target.x - self.x
                dy = target.y - self.y
                dist = math.hypot(dx, dy)
                if dist > 0:
                    self.x += PLAYER_SPEED * dx / dist
                    self.y += PLAYER_SPEED * dy / dist
                self.shoot(bullets, 'revolver', target.x, target.y)

class Bullet:
    def __init__(self, x, y, angle, damage):
        self.x = x
        self.y = y
        self.angle = angle
        self.speed = 10
        self.damage = damage
        self.radius = 5

    def move(self):
        self.x += math.cos(self.angle) * self.speed
        self.y += math.sin(self.angle) * self.speed

    def draw(self):
        pygame.draw.circle(screen, WHITE, (int(self.x), int(self.y)), self.radius)

class EnemyBullet:
    def __init__(self, x, y, angle, damage=10):
        self.x = x
        self.y = y
        self.angle = angle
        self.speed = 6
        self.damage = damage
        self.radius = 4

    def move(self):
        self.x += math.cos(self.angle) * self.speed
        self.y += math.sin(self.angle) * self.speed

    def draw(self):
        pygame.draw.circle(screen, (255, 100, 100), (int(self.x), int(self.y)), self.radius)

class Enemy:
    def __init__(self):
        self.x = random.randint(0, WIDTH)
        self.y = random.randint(0, HEIGHT)
        self.size = ENEMY_SIZE
        self.health = 100
        self.last_shot = pygame.time.get_ticks()

    def draw(self):
        point1 = (self.x, self.y - self.size)
        point2 = (self.x - self.size, self.y + self.size)
        point3 = (self.x + self.size, self.y + self.size)
        pygame.draw.polygon(screen, RED, [point1, point2, point3])

    def hit(self, damage):
        self.health -= damage
        return self.health <= 0

    def move_towards(self, players):
        living_players = [p for p in players if p.alive]
        if living_players:
            target = living_players[0]
            dx = target.x - self.x
            dy = target.y - self.y
            dist = math.hypot(dx, dy)
            if dist > 0:
                self.x += ENEMY_SPEED * dx / dist
                self.y += ENEMY_SPEED * dy / dist

    def shoot(self, target):
        now = pygame.time.get_ticks()
        if now - self.last_shot > 2000:
            angle = math.atan2(target.y - self.y, target.x - self.x)
            enemy_bullets.append(EnemyBullet(self.x, self.y, angle))
            self.last_shot = now

players = [Player(WIDTH // 2 + i * 50, HEIGHT // 2 + i * 50, is_main=(i == 0)) for i in range(4)]
bullets = []
enemies = []
enemy_bullets = []
current_weapon = 'revolver'
spawn_timer = pygame.time.get_ticks()
spawn_interval = 10000

running = True
while running:
    screen.fill(BLACK)
    keys = pygame.key.get_pressed()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
            elif event.key == pygame.K_f:
                fullscreen = not fullscreen
                screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN if fullscreen else 0)
                WIDTH, HEIGHT = screen.get_size()
            elif event.key == WEAPONS['revolver']['key']:
                current_weapon = 'revolver'
            elif event.key == WEAPONS['sniper']['key']:
                current_weapon = 'sniper'
            elif event.key == WEAPONS['ak47']['key']:
                current_weapon = 'ak47'
            elif event.key == pygame.K_5:
                enemies.append(Enemy())
            elif event.key == pygame.K_3:
                for player in players:
                    player.health = 300
                    player.alive = True
            elif event.key == pygame.K_2:
                for player in players:
                    player.health = 300
                    player.alive = True

    if pygame.time.get_ticks() - spawn_timer > spawn_interval:
        for _ in range(4):
            enemies.append(Enemy())
        spawn_timer = pygame.time.get_ticks()

    all_dead = all(not p.alive for p in players)

    if all_dead:
        game_over_text = large_font.render("GAME OVER", True, RED)
        revive_text = font.render("Press 3 to revive", True, WHITE)
        screen.blit(game_over_text, (WIDTH // 2 - game_over_text.get_width() // 2, HEIGHT // 2 - 50))
        screen.blit(revive_text, (WIDTH // 2 - revive_text.get_width() // 2, HEIGHT // 2 + 20))
    else:
        for enemy in enemies:
            enemy.move_towards(players)
            enemy.shoot(players[0])

        for player in players:
            if player.alive:
                if player.is_main:
                    player.move(keys)
                    if pygame.mouse.get_pressed()[0]:
                        mx, my = pygame.mouse.get_pos()
                        player.shoot(bullets, current_weapon, mx, my)
                else:
                    player.move()
            player.draw()

        for bullet in bullets[:]:
            bullet.move()
            bullet.draw()
            for enemy in enemies[:]:
                dx = bullet.x - enemy.x
                dy = bullet.y - enemy.y
                dist = math.hypot(dx, dy)
                if dist < bullet.radius + enemy.size:
                    if enemy.hit(bullet.damage):
                        enemies.remove(enemy)
                    if bullet in bullets:
                        bullets.remove(bullet)
                    break

        for ebullet in enemy_bullets[:]:
            ebullet.move()
            ebullet.draw()
            for player in players:
                if not player.alive:
                    continue
                dx = ebullet.x - player.x
                dy = ebullet.y - player.y
                dist = math.hypot(dx, dy)
                if dist < ebullet.radius + player.radius:
                    player.health -= ebullet.damage
                    if player.health <= 0:
                        player.alive = False
                    if ebullet in enemy_bullets:
                        enemy_bullets.remove(ebullet)

        for enemy in enemies:
            enemy.draw()

    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
input("Presiona Enter para salir...")
